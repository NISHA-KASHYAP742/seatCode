
   let seatNo = 0;
   var currentFloat = 'left';
   var seatPositionArray = [];
   var noOfColumn = 0;

   $(document).ready(function () {
    let leftSideSeat = 2;
    let rightSideSeat = 3;
    let noOfRow = 10;

    noOfColumn = leftSideSeat + rightSideSeat + 1;
    let leftColorArray = [],
     leftSeatPositionArray = [];
    let rightColorArray = [],
     rightSeatPositionArray = [];
    let passegeColor = ["#FFFFFF"];
    let displaySeat = "00";
    let window = ['#99DBF5'];
    let middle = ['#FFDEDE'];
    let side = ['#F6FA70'];
    if (leftSideSeat == 2) {
     leftColorArray = [window, side];
     leftSeatPositionArray = ["W", "A"];
    } else {
     leftColorArray = [window, middle, side];
     leftSeatPositionArray = ["W", "M", "A"];
    }
    if (rightSideSeat == 2) {
     rightColorArray = [side, window];
     rightSeatPositionArray = ["A", "W"];
    } else {
     rightColorArray = [side, middle, window];
     rightSeatPositionArray = ["A", "M", "W"];
    }
    var passageSeatPositionArray = ["P"];
    var colorArray = leftColorArray.concat(passegeColor, rightColorArray);
    seatPositionArray = leftSeatPositionArray.concat(passageSeatPositionArray, rightSeatPositionArray);

    for (var r = 1; r <= noOfRow; r++) {
     var newDiv = $('<div>', {
      class: 'col-container'
     });

     for (let col = 0; col < noOfColumn; col++) {
      let displaySeat = "";
      var newCol = "";

      if (col === leftSideSeat) {
       displaySeat = "";
       newCol = $('<div>', {
        class: 'col',
        style: 'margin-left:15px;margin-right:15px;margin-top:10px;background: ' + colorArray[col]
       });
      } else {
       seatNo++;
       displaySeat = seatNo.toString().padStart(2, '0');
       newCol = $('<div>', {
        class: 'col',
        style: 'background: ' + colorArray[col]
       });
      }

      var seatNumber = $('<span>', {
       class: 'seat-number'
      });
      seatNumber.text(displaySeat);
      newCol.append(seatNumber);
      newDiv.append(newCol);
     }

     $('#container').append(newDiv);
    }

    $('#container').append('<div class="col-container1"><div class="column"><div class="toilet3"style=margin-top:10px;>Rest<br>Room</div><div class="toilet4">Rest<br>Room</div></div></div>');

    $('#addDivButton').click(function () {
     var rowAppend = "";
     rowAppend = rowAppend + "<div class='col-container'>";
     for (var col = 0; col < noOfColumn; col++) {
      let displaySeat = "";
      if (col === leftSideSeat) {
       displaySeat = "";
       rowAppend = rowAppend + "<div class='col' style='float:" + currentFloat + ";margin-left:15px;margin-right:15px;background-color:" + colorArray[col] + ";'>" + displaySeat + "</div>";
      } else {
       seatNo++;
       displaySeat = seatNo.toString().padStart(2, '0');
       rowAppend = rowAppend + "<div class='col' style='float:" + currentFloat + ";margin-top:10px;background-color:" + colorArray[col] + ";'>" + displaySeat + "</div>";
      }
     }
     rowAppend = rowAppend + "</div>";
     $('#container .col-container').last().append(rowAppend);
    });

    $('#removeDivButton').click(function () {
     $('#container .col-container').last().remove();
     seatNo = seatNo - leftSideSeat - rightSideSeat;
    });

    $('#saveData').click(function () {
     var seatPropertyArray = [];
     let rowNo = 0,
      colNo = 0;
     $('#container .col-container').each(function (index) {
      rowNo = index + 1;
      for (let seat = 0; seat <= seatNo; seat++) {
       colNo = seat + 1;
       let seatProperty = {};
       seatProperty.col = colNo;
       seatProperty.row = rowNo;
       seatProperty.seatNo = $(this).find(".col:eq(" + seat + ")").text();

       seatProperty.seatPosition = seatPositionArray[seat];
       let passageValue = false;
       if (seatPositionArray[seat] == "P") {
        passageValue = true;
       } else {
        passageValue = false;
       }
       seatProperty.passageFlag = passageValue;
       seatPropertyArray.push(seatProperty);
      }
     });
      localStorage.setItem('seatPropertyArray', JSON.stringify(seatPropertyArray));
    //  alert(JSON.stringify(seatPropertyArray));
      var navigateButton = document.getElementById('saveData');
      navigateButton.addEventListener('click', function () {
        window.location.href = 'ind.html';
      });
    });



    $('#changeFloatButton').click(function () {
     $('.col').each(function () {
      $(this).css('float', currentFloat === 'left' ? 'right' : 'left');
     });
     if (currentFloat == 'left')
      currentFloat = 'right';
     else
      currentFloat = 'left';
    });

    $(document).on("click", ".col", function (e) {
     $('.col').removeClass('selected');
     $(this).addClass('selected');
     var pos = $(this).offset();

     $('#seatLayoutOperationList').css({
      'position': 'absolute',
      'top': pos.top - 30 + 'px',
      'left': pos.left + 'px',
      'display': 'inline'
     }).appendTo($(this));

     e.stopPropagation();
    });


    $(document).on("click", "#seatLayoutOperationList", function (e) {

     let element = document.getElementById("seatLayoutOperationList")
     parent = element.parentElement
     document.body.appendChild(element);
     element.style.display = "none";


     parent.style.backgroundColor = document.body.style.backgroundColor;
     parent.textContent = "10";
     parent.style.opacity = 0;

     seatNo--;
     e.stopPropagation();

     let colGroup = document.getElementsByClassName("seat-number");

     // console.log(colGroup.length)
     let num = 1;
     for (let i of colGroup) {
      if (i.innerHTML != "") {
       i.innerHTML = num.toString().padStart(2, "0");
       // console.log(i);
       num++;
      }
     }
    });
   });
